package com.example.phone_direct_caller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
