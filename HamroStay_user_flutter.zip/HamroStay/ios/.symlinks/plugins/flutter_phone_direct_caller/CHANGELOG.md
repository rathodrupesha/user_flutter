## 2.1.1
* Closes [#19](https://github.com/yanisalfian/flutter-phone-direct-caller/issues/19) 

## 2.1.0
* Closes [#16](https://github.com/yanisalfian/flutter-phone-direct-caller/issues/16)
* Closes [#12](https://github.com/yanisalfian/flutter-phone-direct-caller/issues/12)
* Closes [#13](https://github.com/yanisalfian/flutter-phone-direct-caller/issues/13)

## 2.0.0
* null safety

## 1.0.1

* Initial release.
* Migration to AndroidX
